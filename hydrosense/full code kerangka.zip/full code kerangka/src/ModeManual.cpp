#include "Modes.h"

void handleModeManual() {
  switch (state) {
    case STATE_M_BACA_PERINTAH:
      if (bacaPerintahManual()) {
        state = STATE_M_CEK_INTERLOCK;
      } else if (millis() - timerPollTerakhir >= INTERVAL_POLL_MS) {
        timerPollTerakhir = millis();
        state = STATE_A_CEK_STOP;
      }
      break;

    case STATE_M_CEK_INTERLOCK:
      if (interlockAman()) {
        state = STATE_M_JALANKAN_PERINTAH;
      } else {
        tolakPerintahDenganAlert();
        state = STATE_A_CEK_STOP;
      }
      break;

    case STATE_M_JALANKAN_PERINTAH:
      jalankanPerintahPompaValve();
      state = STATE_M_KIRIM_DATA;
      break;

    case STATE_M_KIRIM_DATA:
      hasilPhTerakhir = bacaProsesPH();
      tssTerakhir     = bacaRataRataTSS(5); // MEDIAN_SAMPLES = 5
      if (hasilPhTerakhir.valid) {
        if (!kirimDataKeAPI(hasilPhTerakhir, tssTerakhir)) {
          simpanKeBuffer(hasilPhTerakhir, tssTerakhir);
        }
      } else {
        kirimStatusErrorKeAPI(hasilPhTerakhir.modbusErrorCount);
      }
      state = STATE_M_BACA_PERINTAH;
      break;

    default:
      // State lainnya bukan milik manual
      break;
  }
}

// ---------------- Dummy Implementasi ----------------
bool bacaPerintahManual() {
  // TODO: GET ke tabel perintah manual, true jika ada perintah baru
  return false;
}

bool interlockAman() {
  // TODO: cek kondisi keselamatan sebelum eksekusi perintah manual
  return true;
}

void tolakPerintahDenganAlert() {
  tampilkanError("Perintah ditolak - interlock tidak aman");
  // TODO: kirim status penolakan + alert ke Supabase
}

void jalankanPerintahPompaValve() {
  // TODO: eksekusi perintah aktual sesuai isi perintah dari Supabase
}

