#include "Network.h"

// ========================= KONFIGURASI SUPABASE =========================
const char* SUPABASE_URL      = "https://xxxxxxxx.supabase.co";
const char* SUPABASE_API_KEY  = "isi_dengan_anon_atau_service_key";
const char* TABLE_READINGS = "water_quality_readings";
const char* TABLE_MODE     = "system_control";

const int UKURAN_BUFFER = 20;
DataSample buffer[20];
int bufferHead = 0;

void connectWiFi() {
  Serial.print("Menghubungkan ke WiFi...");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

bool wifiTersambung() { 
  return WiFi.status() == WL_CONNECTED; 
}

bool supabaseSiap() {
  if (!wifiTersambung()) return false;
  HTTPClient http;
  String url = String(SUPABASE_URL) + "/rest/v1/" + TABLE_MODE + "?select=id&limit=1";
  http.begin(url);
  http.addHeader("apikey", SUPABASE_API_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_API_KEY);
  int kodeHttp = http.GET();
  http.end();
  return (kodeHttp == 200);
}

bool kirimDataKeAPI(HasilPH hasilPh, float tss) {
  if (!wifiTersambung() || !hasilPh.valid) return false;

  HTTPClient http;
  String url = String(SUPABASE_URL) + "/rest/v1/" + TABLE_READINGS;
  http.begin(url);
  http.addHeader("apikey", SUPABASE_API_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_API_KEY);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Prefer", "return=minimal");

  String payload = "{";
  payload += "\"device_id\":\"" + String(DEVICE_ID) + "\",";
  payload += "\"ph\":" + String(hasilPh.ph, 2) + ",";
  payload += "\"temperature_c\":" + String(hasilPh.suhu, 1) + ",";
  payload += "\"tss\":" + String(tss, 2) + ",";
  payload += "\"quality\":\"" + hasilPh.kualitas + "\",";
  payload += "\"compliant\":" + String(hasilPh.compliant ? "true" : "false") + ",";
  payload += "\"diagnostics\":{";
  payload += "\"raw_register_ph\":" + String(hasilPh.rawPh) + ",";
  payload += "\"raw_register_temp\":" + String(hasilPh.rawTemp) + ",";
  payload += "\"sd_ph\":" + String(hasilPh.sd, 4) + ",";
  payload += "\"drift_ph_per_min\":" + String(hasilPh.drift, 4) + ",";
  payload += "\"modbus_errors\":" + String(hasilPh.modbusErrorCount);
  payload += "}}";

  int kodeHttp = http.POST(payload);
  http.end();
  return (kodeHttp == 200 || kodeHttp == 201);
}

bool kirimStatusErrorKeAPI(int modbusErrorCount) {
  if (!wifiTersambung()) return false;

  HTTPClient http;
  String url = String(SUPABASE_URL) + "/rest/v1/" + TABLE_READINGS;
  http.begin(url);
  http.addHeader("apikey", SUPABASE_API_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_API_KEY);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Prefer", "return=minimal");

  String payload = "{";
  payload += "\"device_id\":\"" + String(DEVICE_ID) + "\",";
  payload += "\"ph\":null,";
  payload += "\"temperature_c\":null,";
  payload += "\"quality\":\"error\",";
  payload += "\"compliant\":false,";
  payload += "\"diagnostics\":{\"modbus_errors\":" + String(modbusErrorCount) + "}";
  payload += "}";

  int kodeHttp = http.POST(payload);
  http.end();
  return (kodeHttp == 200 || kodeHttp == 201);
}

void simpanKeBuffer(HasilPH hasilPh, float tss) {
  buffer[bufferHead].ph = hasilPh.ph;
  buffer[bufferHead].suhu = hasilPh.suhu;
  buffer[bufferHead].tss = tss;
  buffer[bufferHead].kualitas = hasilPh.kualitas;
  buffer[bufferHead].compliant = hasilPh.compliant;
  buffer[bufferHead].rawPh = hasilPh.rawPh;
  buffer[bufferHead].rawTemp = hasilPh.rawTemp;
  buffer[bufferHead].sd = hasilPh.sd;
  buffer[bufferHead].drift = hasilPh.drift;
  buffer[bufferHead].modbusErrorCount = hasilPh.modbusErrorCount;
  buffer[bufferHead].phValid = true;
  buffer[bufferHead].terisi = true;
  bufferHead = (bufferHead + 1) % UKURAN_BUFFER;
}

void cobaKirimUlangBuffer() {
  if (!wifiTersambung()) return;
  for (int i = 0; i < UKURAN_BUFFER; i++) {
    if (buffer[i].terisi) {
      HasilPH hp;
      hp.valid = true;
      hp.ph = buffer[i].ph; hp.suhu = buffer[i].suhu;
      hp.kualitas = buffer[i].kualitas; hp.compliant = buffer[i].compliant;
      hp.rawPh = buffer[i].rawPh; hp.rawTemp = buffer[i].rawTemp;
      hp.sd = buffer[i].sd; hp.drift = buffer[i].drift;
      hp.modbusErrorCount = buffer[i].modbusErrorCount;

      if (kirimDataKeAPI(hp, buffer[i].tss)) {
        buffer[i].terisi = false;
      } else {
        break; // masih gagal, hindari spam - coba lagi loop berikutnya
      }
    }
  }
}

bool bacaModeOperasiDariSupabase() {
  if (!wifiTersambung()) return true;
  HTTPClient http;
  String url = String(SUPABASE_URL) + "/rest/v1/" + TABLE_MODE + "?select=mode&order=updated_at.desc&limit=1";
  http.begin(url);
  http.addHeader("apikey", SUPABASE_API_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_API_KEY);
  int kodeHttp = http.GET();
  bool otomatis = true;
  if (kodeHttp == 200) {
    String respon = http.getString();
    otomatis = (respon.indexOf("\"otomatis\"") != -1); // parsing sederhana
  }
  http.end();
  return otomatis;
}

