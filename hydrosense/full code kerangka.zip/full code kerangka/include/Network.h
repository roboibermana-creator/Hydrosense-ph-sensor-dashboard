#ifndef NETWORK_H
#define NETWORK_H

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include "Config.h"

// ========================= HASIL PROSES pH =========================
struct HasilPH {
  bool   valid;          // lolos gerbang validitas & cukup sample sukses?
  float  ph;             // sudah median + dibulatkan 2 desimal
  float  suhu;            // dibulatkan 1 desimal
  float  sd;              // standar deviasi sample (pH)
  float  drift;            // pH per menit
  String kualitas;         // "good" | "fair" | "unstable" | "error"
  bool   compliant;        // baku mutu 6-9 DAN kualitas good/fair
  uint16_t rawPh;
  int16_t  rawTemp;
  int    modbusErrorCount;
};

// ========================= BUFFER OFFLINE =========================
struct DataSample {
  float ph, suhu, tss;
  String kualitas;
  bool compliant;
  uint16_t rawPh;
  int16_t rawTemp;
  float sd, drift;
  int modbusErrorCount;
  bool phValid;     // false -> ini record status error (ph tidak dikirim sbg angka)
  bool terisi;
};

extern const int UKURAN_BUFFER;
extern DataSample buffer[];
extern int bufferHead;

// Konfigurasi API
extern const char* SUPABASE_URL;
extern const char* SUPABASE_API_KEY;
extern const char* TABLE_READINGS;
extern const char* TABLE_MODE;

void connectWiFi();
bool wifiTersambung();
bool supabaseSiap();
bool kirimDataKeAPI(HasilPH hasilPh, float tss);
bool kirimStatusErrorKeAPI(int modbusErrorCount);
void simpanKeBuffer(HasilPH hasilPh, float tss);
void cobaKirimUlangBuffer();
bool bacaModeOperasiDariSupabase();

#endif // NETWORK_H
